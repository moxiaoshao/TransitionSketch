## How to run

Before running, change the filename to your dataset direction (Line 50 in src/main.cpp).

After that, compile and run the program with the following commands.

```bash
$ cmake .
$ make
$ ./bin/demo
```
